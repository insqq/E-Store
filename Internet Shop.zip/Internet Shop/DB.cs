﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;
using System.Data;
using System.Web.UI.WebControls;

namespace Internet_Shop
{
    static public class DB
    {
        static private MySqlConnection con = new MySqlConnection
            (@"Data Source=localhost; DataBase=internet_store; User ID=root; Password=root");

        static public String loginValidation(System.Web.SessionState.HttpSessionState Session, String nickname, String pw)
        {
            con.Open();
            string checkUser = "select count(*) from users where NickName='" + nickname + "'";
            MySqlCommand com = new MySqlCommand(checkUser, con);
            int tmp = Convert.ToInt32(com.ExecuteScalar().ToString());
            con.Close();
            if (tmp == 1)
            {
                con.Open();
                string Query = "select Password from users where NickName='" + nickname + "'";
                MySqlCommand pcom = new MySqlCommand(Query, con);
                String password = pcom.ExecuteScalar().ToString().Replace(" ", "");
                con.Close();
                if (password == pw)
                {
                    Session["name"] = nickname;

                    con.Open();
                    Query = "select account_type from users where NickName='" + nickname + "'";
                    pcom = new MySqlCommand(Query, con);
                    Int32 account_type = Convert.ToInt32(pcom.ExecuteScalar());
                    con.Close();
                    Session["account_type"] = account_type;
                }
                else
                {
                    return "incorrect password";
                }
            }
            else return "incorrect login";
            return "";
        }

        static public String registration(String name, String sureName, String nickName, String password, String email)
        {
            Guid userGUID = Guid.NewGuid();
            Guid cartGUID = Guid.NewGuid();
            con.Open();
            string checkUser = "select count(*) from users where NickName='" + nickName + "'";
            MySqlCommand com = new MySqlCommand(checkUser, con);
            int tmp = Convert.ToInt32(com.ExecuteScalar().ToString());
            if (tmp == 1)
            {
                con.Close();
                return "user with same nickname allready register";
            }

            MySqlCommand cmdDataBase = new MySqlCommand("insert into users (idUsers, Name, Surename, NickName, Password, Email, cart_idcart) values('" +
                userGUID.ToString() + "', '" + name + "', '" + sureName + "', '" + nickName + "', '" + password + "', '" + email + "', '" + cartGUID.ToString() + "');", con);
            cmdDataBase.ExecuteReader();
            con.Close();

            con.Open();
            cmdDataBase = new MySqlCommand("insert into cart (idcart, users_idUsers) values('" + cartGUID.ToString() + "', '" + userGUID.ToString() + "');", con);
            cmdDataBase.ExecuteScalar();

            con.Close();


            return "";
        }

        static public String getUserID(String nickname)
        {
            con.Open();
            MySqlCommand cmdDataBase = new MySqlCommand("Select idUsers from users where NickName = '" + nickname + "';  ", con);
            String userID = cmdDataBase.ExecuteScalar().ToString().Replace(" ", "");
            con.Close();
            return userID;
        }

        static public void addToCart(String userID, String productID)
        {
            con.Open();
            MySqlCommand cmdDataBase = new MySqlCommand("Select cart_idcart from users where idUsers='" + userID + "'; ", con);
            String cartID = cmdDataBase.ExecuteScalar().ToString().Replace(" ", "");
            con.Close();

            con.Open();
            cmdDataBase = new MySqlCommand("select count from cartsitems where products_idproducts ='" +
                productID + "' AND idCartItems ='" + cartID + "' ", con);
            if (cmdDataBase.ExecuteScalar() == null)
            {
                con.Close();
                con.Open();
                cmdDataBase = new MySqlCommand("insert into cartsitems (idCartItems, products_idproducts) values('" +
                    cartID + "', '" + productID + "') ", con);
                cmdDataBase.ExecuteScalar();
                con.Close();
                return;
            }
            String tmp = cmdDataBase.ExecuteScalar().ToString();
            con.Close();
            if (tmp != null)
            {
                con.Close();
                con.Open();
                cmdDataBase = new MySqlCommand("UPDATE cartsitems SET count= '" + (Convert.ToInt32(tmp)+1) + "' where products_idproducts ='" + productID + "' AND idCartItems ='" + cartID + "'  ", con);
                cmdDataBase.ExecuteScalar();
                con.Close();
                return;
            }
        }

        static public void getCartItems(GridView gv, String userID)
        {
            con.Open();
            DataTable dt = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter(
                "Select product_name, count, current_price from cartsitems ci inner join cart c inner join products p ON ci.idCartItems = c.idcart where users_idUsers = '" +
                userID + "' and ci.products_idproducts = p.idproducts;", con);
            adapter.Fill(dt);
            con.Close();
            dt.Columns.Add("total price", typeof(String));
            double total = 0;
            foreach (DataRow dr in dt.Rows)
            {
                dr[3] = Convert.ToDouble(dr[1]) * Convert.ToDouble(dr[2]);
                total += Convert.ToDouble(dr[3]);
            }

            dt.Rows.Add();
            dt.Columns.Add("edit", typeof(ButtonField));
            foreach (DataRow dr in dt.Rows)
            {
                if (dr[0].ToString() == "" || dr[0] == null)
                {
                    dr[0] = "total: ";
                    dr[3] = total;
                }
                else
                {
                    Button btn = new Button();
                    //dr[4] = btn;

                }
            }
            gv.DataSource = dt;
            gv.DataBind();
        }

        static public void loadProducts(List<productInfo> l)
        {
            con.Open();
            DataTable dt = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter("select * from products p inner join thumbs_pic t on p.idproducts=t.IDproduct", con);
            adapter.Fill(dt);
            con.Close();
            foreach (DataRow dr in dt.Rows)
            {
                l.Add(new productInfo(dr));
            }
        }

        static public void loadProducts(List<productInfo> l, String category)
        {
            con.Open();
            DataTable dt = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter("select * from products p inner join thumbs_pic t on p.idproducts=t.IDproduct where product_type = '" + category + "';", con);
            adapter.Fill(dt);
            con.Close();
            foreach (DataRow dr in dt.Rows)
            {
                l.Add(new productInfo(dr));
            }
        }

        static public productInfo loadProduct(String pID, String userID)
        {
            productInfo pInfo = null;
            con.Open();
            DataTable dt = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter("select * from products p inner join thumbs_pic t on p.idproducts=t.IDproduct where idproducts='" + pID + "'; ", con);
            adapter.Fill(dt);
            con.Close();
            foreach (DataRow dr in dt.Rows)
            {
                pInfo = new productInfo(dr);
            }

            return pInfo;
        }

        static public void addProduct(String name, String PicPath, String CurrentPrice, String MaxPrice,
            String Info, String productType, String main_big_pic, String inStoc, String weight, String insurance, String add_date,
            String thumb_spic1, String thumb_spic2, String thumb_spic3, String thumb_bpic1, String thumb_bpic2, String thumb_bpic3)
        {
            Guid newGUID = Guid.NewGuid();
            String ID = newGUID.ToString();

            con.Open();
            MySqlCommand cmdDataBase = new MySqlCommand(
                "insert into products (idproducts, product_name, product_pic, current_price, max_price,info,product_type,main_big_pic,"+
            " inStoc, weight, insurance, add_date) values('" +ID + "', '" + name + "', '" + PicPath + "', '" + CurrentPrice + "', '" +
            MaxPrice + "', '" + Info + "', '" + productType + "' , '" + main_big_pic + "'  , '" + inStoc + "'  , '" + weight +
            "' , '" + insurance + "' , '" + add_date + "' );", con);
            cmdDataBase.ExecuteReader();
            con.Close();

            con.Open();
            cmdDataBase = new MySqlCommand(
                "insert into thumbs_pic (IDproduct, thumbs_pic1, thumbs_pic2, thumbs_pic3, thumbs_pic4, thumbs_pic5, thumbs_pic6)" +
                "values('" + ID + "', '" + thumb_spic1 + "' , '" + thumb_spic2 + "' , '" + thumb_spic3 +
            "' , '" + thumb_bpic1 + "' , '" + thumb_bpic2 + "' , '" + thumb_bpic3 + "');", con);
            cmdDataBase.ExecuteReader();
            con.Close();
        }

        static public String getTotalItems(String userID)
        {
            con.Open();
            MySqlCommand cmdDataBase = new MySqlCommand(
                "select SUM(count) from cartsitems ci inner join cart c on ci.idCartItems = c.idcart where users_idUsers = '" +
                userID + "';", con);

            String count = cmdDataBase.ExecuteScalar().ToString().Replace(" ", "");
            con.Close();
            return count;
        }

        static public void loadMainPagePosts(List<Main_Page_Post> l)
        {
            con.Open();
            DataTable dt = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter("select title, date, titlePicWay, content, NickName from main_page_posts p inner join users u on p.users_idUsers=u.idUsers;", con);
            adapter.Fill(dt);
            con.Close();
            foreach (DataRow dr in dt.Rows)
            {
                l.Add(new Main_Page_Post(dr));
            }
        }

        static public void loadSimilarProducts(List<productInfo> l, productInfo pInfo)
        {
            con.Open();
            DataTable dt = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter("select * from products p inner join thumbs_pic t on p.idproducts=t.IDproduct where product_type = ''", con);
            adapter.Fill(dt);
            con.Close();
            foreach (DataRow dr in dt.Rows)
            {
                l.Add(new productInfo(dr));
            }
        }

        static public void loadNewProduct(ref productInfo product)
        {
            con.Open();
            DataTable dt = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter("select * from products p inner join thumbs_pic t on p.idproducts=t.IDproduct order by add_date desc limit 6", con);
            adapter.Fill(dt);
            con.Close();

            Random rnd = new Random();
            int randomNumber = rnd.Next(0, dt.Rows.Count);

            product = new productInfo(dt.Rows[randomNumber]);
        }

        static public Double getTotalPrice(String userID)
        {
            con.Open();
            DataTable dt = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter(
                "Select count, current_price from cartsitems ci inner join cart c inner join products p ON ci.idCartItems = c.idcart where users_idUsers = '" +
                userID + "' and ci.products_idproducts = p.idproducts;", con);
            adapter.Fill(dt);
            con.Close();
            Double total = 0;
            foreach (DataRow dr in dt.Rows)
            {
                total += Convert.ToDouble(dr[0]) * Convert.ToDouble(dr[1]);
            }

            return total;
        }

        static public void clearCart(String userID)
        {
            con.Open();
            MySqlCommand cmdDataBase = new MySqlCommand(
                "Delete from cartsitems where idCartItems = (select distinct idcart from cart where users_idUsers = '"+ userID + "');", con);
            cmdDataBase.ExecuteScalar();
            con.Close();
        }

        static public void createOrder(String userID)
        {
            Guid orderID = Guid.NewGuid();

            con.Open();
            DataTable dt = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter(
                "Select count, current_price from cartsitems ci inner join cart c inner join products p ON ci.idCartItems = c.idcart where users_idUsers = '" +
                userID + "' and ci.products_idproducts = p.idproducts;", con);
            adapter.Fill(dt);
            con.Close();
            Double total = 0;
            foreach (DataRow dr in dt.Rows)
            {
                total += Convert.ToDouble(dr[0]) * Convert.ToDouble(dr[1]);
            }

            con.Open();
            MySqlCommand cmdDataBase = new MySqlCommand("insert into orders (idorders, status, users_idUsers, date, totalPrice) values ('" + orderID.ToString()
                + "', 'in line', '" + userID + "', '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "', '" + total.ToString() + "' );", con);
            cmdDataBase.ExecuteScalar();
            con.Close();

            con.Open();
            cmdDataBase = new MySqlCommand("Insert into orderitems (productId, orders_idorders, count) select products_idproducts as productId, '" +
                orderID.ToString() + "' as orders_idorders, count from cartsitems where idCartItems = (select distinct idcart from cart where users_idUsers = '" 
                + userID + "');", con);

            cmdDataBase.ExecuteScalar();
            con.Close();
        }

        static public void getOrderList(GridView gv, String userID)
        {
            con.Open();
            DataTable dt = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter("select date, totalPrice, status from orders where users_idUsers = '" + userID + "';", con);
            adapter.Fill(dt);
            con.Close();

            dt.Columns.Add("", typeof(LinkButton));
            
            //creating the first row of Gridview to be editable
            

            gv.DataSource = dt;
            gv.DataBind();
        }

        static public DataTable getCategorys()
        {
            con.Open();
            DataTable dt = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter("select product_type from products group by product_type;", con);
            adapter.Fill(dt);
            con.Close();

            return dt;
        }

        static public void addComment(String text, String idProduct, String idUser)
        {
            Guid commentID = Guid.NewGuid();
            con.Open();
            MySqlCommand com = new MySqlCommand("insert into comments (idcomments, text, date, products_idproducts, users_idUsers) values('"
                + commentID.ToString() + "', '" + text + "', '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "', '" + 
                idProduct +"', '" + idUser + "'); ", con);
            com.ExecuteScalar();
            con.Close();
        }

        static public DataTable loadComments(String idProduct)
        {
            con.Open();
            DataTable dt = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter("select Name, text, date from comments c join users u on c.users_idUsers = u.idUsers where products_idproducts = '" + idProduct + "'", con);
            adapter.Fill(dt);
            con.Close();

            return dt;
        }

    }
}