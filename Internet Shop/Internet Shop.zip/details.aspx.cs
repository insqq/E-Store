﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace Internet_Shop
{
    public partial class details : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String productID = Session["productID"].ToString();
            String userID = null;
            if (Session["name"] != null)
            {
                userID = DB.getUserID(Session["name"].ToString());
            }

            //List<productInfo> productsList = new List<productInfo>();
            //DB.loadSimilarProducts(productsList, DB.loadProduct(productID, userID).getpInfo());

            details_product pDetails = new details_product(DB.loadProduct(productID, userID), userID, this);
            PlaceHolder1.Controls.Add(pDetails);


            /*foreach (productInfo var in productsList)
            {
                ProductBox pb = new ProductBox(var, userID, this);
                PlaceHolder1.Controls.Add(pb);
            }*/
            
            leaveComment tb = new leaveComment(DB.loadProduct(productID, userID), userID, this);
            PlaceHolder_leaveComment.Controls.Add(tb);


        }

        protected void Page_PreInit(object sender, EventArgs e)
        {
            if (Session["name"] != null && this.MasterPageFile == "/Site.Master")
            {
                this.MasterPageFile = "/Logined.Master";
            }

            if (Session["name"] == null && this.MasterPageFile == "/Logined.Master")
            {
                this.MasterPageFile = "/Site.Master";
            }
        }
    }
}