﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI.HtmlControls;

namespace Internet_Shop
{
    public class Main_Page_Post : HtmlGenericControl
    {
        String title;
        String date;
        String titlePicWay;
        String postetBy;
        String content;

        public Main_Page_Post(DataRow dr)
        {
            title = dr[0].ToString();
            date = dr[1].ToString();
            titlePicWay = dr[2].ToString();
            content = Encoding.UTF8.GetString((byte[])dr[3]);
            postetBy = dr[4].ToString();

            HtmlGenericControl box = new HtmlGenericControl("div");
            box.Attributes.Add("class", "prod_box_big");
            HtmlGenericControl boxTop = new HtmlGenericControl("div");
            boxTop.Attributes.Add("class", "top_prod_box_big");
            HtmlGenericControl boxCenter = new HtmlGenericControl("div");
            boxCenter.Attributes.Add("class", "center_prod_box_big");
            HtmlGenericControl boxBottom = new HtmlGenericControl("div");
            boxBottom.Attributes.Add("class", "bottom_prod_box_big");

            HtmlGenericControl titleDiv = new HtmlGenericControl("div");
            HtmlGenericControl contentDiv = new HtmlGenericControl("div");
            HtmlGenericControl refImg = null;
            HtmlGenericControl img = null;
            HtmlGenericControl bottomDiv = new HtmlGenericControl("div");

            HtmlAnchor titleRef = new HtmlAnchor();
            titleDiv.Attributes.Add("class", "product_title");
            titleRef.Attributes.Add("runat", "server");
            titleRef.Attributes.Add("style", "font-size: 20px");
            titleRef.InnerText = title;
            titleRef.ServerClick += new EventHandler(titleRef_click);
            titleDiv.Controls.Add(titleRef);
            boxCenter.Controls.Add(titleDiv);

            contentDiv.Attributes.Add("class", "content_div");

            if (content.Length > 200)
            {
                contentDiv.InnerText = content.Remove(200, content.Length - 200) + "...";
            }
            else contentDiv.InnerText = content;
            boxCenter.Controls.Add(contentDiv);

            if (titlePicWay != null)
            {
                img = new HtmlGenericControl("img");
                img.Attributes.Add("src", titlePicWay);

                HtmlAnchor imgRef = new HtmlAnchor();
                imgRef.Attributes.Add("runat", "server");
                imgRef.ServerClick += new EventHandler(titleRef_click);
                imgRef.Controls.Add(img);

                boxCenter.Controls.Add(imgRef);
            }

            bottomDiv.InnerText = date + " " + postetBy;
            bottomDiv.Attributes.Add("class", "bottom_div");
            boxCenter.Controls.Add(bottomDiv);

            box.Controls.Add(boxTop);
            box.Controls.Add(boxCenter);
            box.Controls.Add(boxBottom);
            this.Controls.Add(box);
        }

        protected void titleRef_click(object sender, EventArgs e)
        {
            
        }
    }
}