﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.IO;
using System.Text;

namespace Internet_Shop
{
    public class productInfo
    {
        public String ID;
        public String name;
        public String pic;
        public String current_price;
        public String max_price;
        public String info;
        public String product_type;
        public String Main_big_pic;
        public String[,] thumbs_pic;
        public String inStoc;
        public String weight;
        public String insurance;
        public String add_date;

        public productInfo(DataRow dr)
        {
            thumbs_pic = new String[3, 2];

            ID = dr[0].ToString();
            name = dr[1].ToString();
            pic = dr[2].ToString();
            current_price = dr[3].ToString();
            max_price = dr[4].ToString();
            MemoryStream stream = new MemoryStream((byte[])dr[5]);
            StreamReader reader = new StreamReader(stream, Encoding.UTF8);
            info = reader.ReadToEnd();
            product_type = dr[6].ToString();
            Main_big_pic = dr[7].ToString();
            inStoc = dr[8].ToString();
            weight = dr[9].ToString();
            insurance = dr[10].ToString();
            add_date = dr[11].ToString();


            thumbs_pic[0, 0] = dr[13].ToString();
            thumbs_pic[1, 0] = dr[14].ToString();
            thumbs_pic[2, 0] = dr[15].ToString();
            thumbs_pic[0, 1] = dr[16].ToString();
            thumbs_pic[1, 1] = dr[17].ToString();
            thumbs_pic[2, 1] = dr[18].ToString();
        }

    }
}