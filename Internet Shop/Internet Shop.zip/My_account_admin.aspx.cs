﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace Internet_Shop
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        private FileUpload[] FU;

        protected void Page_Load(object sender, EventArgs e)
        {
            lbl_top.Text = "";
            FU = new FileUpload[8];

            for (int i = 0; i < 8; i++)
            {
                FU[i] = new FileUpload();
            }

            ph_fu_1.Controls.Add(FU[0]);
            ph_fu_2.Controls.Add(FU[1]);
            ph_fu_3.Controls.Add(FU[2]);
            ph_fu_4.Controls.Add(FU[3]);
            ph_fu_5.Controls.Add(FU[4]);
            ph_fu_6.Controls.Add(FU[5]);
            ph_fu_7.Controls.Add(FU[6]);
            ph_fu_8.Controls.Add(FU[7]);
        }

        protected void Page_PreInit(object sender, EventArgs e)
        {
            if (Convert.ToInt32(Session["Account_type"]) == 0)
            {
                Response.Redirect("My_account.aspx");
            }

            if (Session["name"] != null && this.MasterPageFile == "/Site.Master")
            {
                this.MasterPageFile = "/Logined.Master";
            }

            if (Session["name"] == null && this.MasterPageFile == "/Logined.Master")
            {
                this.MasterPageFile = "/Site.Master";
                Response.Redirect("Enter.aspx");
            }
        }

        protected void btn_addgoods_Click(object sender, EventArgs e)
        {
            Guid newGUID = Guid.NewGuid();
            String ID = newGUID.ToString();

            try
            {
                String rootPath = Server.MapPath("~");
                String dir = rootPath + "/images/loadedpic/" + ID;
                foreach (FileUpload item in FU)
                {
                    if (item.FileName != "" && item.FileName != null)
                    {
                        String fullDir = dir + item.FileName;
                        item.SaveAs(fullDir);
                    }
                }
                

                DB.addProduct(tb_name.Text, "images/loadedpic/"+ ID + FU[0].FileName, tb_priceless.Text, tb_price.Text, tb_info.Text,
                    tb_type.Text, "images/loadedpic/" + ID + FU[1].FileName, DropDownList1.SelectedValue.ToString(),
                    tb_weight.Text, tb_insurance.Text, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), "images/loadedpic/" + ID + FU[2].FileName,
                    "images/loadedpic/" + ID + FU[3].FileName, "images/loadedpic/" + ID + FU[4].FileName, "images/loadedpic/" + ID + FU[5].FileName,
                    "images/loadedpic/" + ID + FU[6].FileName, "images/loadedpic/" + ID + FU[7].FileName);
                lbl_top.Text = "product added";
            }
            catch (Exception ex)
            {
                lbl_top.Text = ex.Message;
            }
        }
    }
}